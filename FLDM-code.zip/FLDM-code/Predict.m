function [ Pre_Labels, Outputs ] = Predict( X, W)
% Input:
% X: n by d
% Y: n by l
% W: d by l
% Output:
% Pre_Labels: n by l
num_instance = size(X, 1);
num_class = size(W, 2);

Outputs = X * W;
threshold = 0;
predict_Label = double(Outputs > threshold);
predict_Label(predict_Label < 1) = -1;

for i = 1: num_instance
    if sum(predict_Label(i, :)) == -num_class
        max_idx = find(Outputs(i, :) == max(Outputs(i, :)), 1);
        predict_Label(i, max_idx) = 1;
    end
end
Pre_Labels = predict_Label;
