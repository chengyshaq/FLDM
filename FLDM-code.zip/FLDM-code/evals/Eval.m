function ResultAll = Eval(Pre_Labels,test_target)
ResultAll=zeros(6,1);

HammingLoss=Hamming_loss(Pre_Labels,test_target);
ExactMatch = Exact_match(Pre_Labels,test_target);
[accuracy]=Accuracy(test_target,Pre_Labels);
[F1]=Fmeasure(test_target,Pre_Labels);
MacroF1 = Macro_F1(test_target,Pre_Labels);
MicroF1 = Micro_F1(test_target,Pre_Labels);

ResultAll(1,1) = HammingLoss;
ResultAll(2,1) = ExactMatch;
ResultAll(3,1) = accuracy;
ResultAll(4,1) = F1;
ResultAll(5,1) = MacroF1;
ResultAll(6,1) = MicroF1;
