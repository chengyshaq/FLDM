clear all; clc
addpath('data','function','evals');
%% Make experiments repeatedly
rng(1);
%% Parameter settings
starttime = datestr(now,0);
deleteData  = 1;
model_DMSW.misRate = 0.2;                  % missing rate of positive class labels
[optParameter, modelparameter] =  init_FLDM;    % parameter settings for FLDM
model_DMSW.modelparameter = modelparameter;
%% load the dataset
load('Cal500.mat');
if exist('train_data','var')==1
    data    = [train_data;test_data];
    target  = [train_target,test_target];
    if deleteData == 1
        clear train_data test_data train_target test_target
    end
end
num_data  = size(data,1);
temp_data = NormalizeFea(data);
target(target==0) = -1;
randorder = randperm(num_data);
cvResult  = zeros(6,modelparameter.cv_num);
%% n-fold cross-validaton
for i = 1:modelparameter.repetitions       
    for j = 1:modelparameter.cv_num
        fprintf('- Repetition - %d/%d,  Cross Validation - %d/%d\n', i, modelparameter.repetitions, j, modelparameter.cv_num);
        [cv_train_data,cv_train_target,cv_test_data,cv_test_target ] = genCV( temp_data,target',randorder,j,modelparameter.cv_num );
        if model_DMSW.misRate > 0
             fprintf('>>> Run model_FLDM for multi-label classification with missing labels\n');
             temptarget = cv_train_target;
             [Y_hat, ~, ~, realpercent]= genML(cv_train_target, model_DMSW.misRate,1); 
             fprintf('\n>>> Missing rate:%.1f, Real Missing rate %.3f\n',model_DMSW.misRate, realpercent);
        else
            fprintf('>>> Run model_FLDM for multi-label classification\n');
            Y_hat = cv_train_target;
        end
       %% Training for FLDM
        [W,obj_loss]  = FLDM(cv_train_data,Y_hat,optParameter);
       %% Prediction and evaluation
        [ Pre_Labels, Outputs ] = Predict( cv_test_data, W);
        fprintf('>>> Evaluation\n');
        tmpResult = Eval(Pre_Labels',cv_test_target');
        cvResult(:,j) = cvResult(:,j) + tmpResult;
    end
end
endtime         = datestr(now,0);
cvResult        = cvResult./modelparameter.repetitions;
Avg_Result      = zeros(6,2);
Avg_Result(:,1) = mean(cvResult,2);
Avg_Result(:,2) = std(cvResult,1,2);
%% Print results
PrintResults(Avg_Result);