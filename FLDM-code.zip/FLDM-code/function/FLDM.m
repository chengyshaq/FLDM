
function [model_DMSW,obj_loss] = FLDM(train_data,Y_hat,optmParameter)
%% optimization parameters
alpha            = optmParameter.alpha;
beta             = optmParameter.beta;
gamma            = optmParameter.gamma;
lambda           = optmParameter.lambda;
maxIter          = optmParameter.maxIter;
miniLossMargin   = optmParameter.minimumLossMargin;

%% initializtion parameters
X = train_data;
Y = Y_hat;
d = size(X,2);
XTX = X'*X;
XTY = X'*Y;
YTY = Y'*Y;
YYT = Y*Y';

% initializtion W
W_s = (XTX+lambda*eye(d))\ XTY;
W_s_1 = W_s;
R     = pdist2( Y'+eps, Y'+eps, 'cosine' );

iter    = 1;
oldloss = 0;

Lip = sqrt(2*(norm(XTX)^2*norm(YTY)^2 + norm(alpha*YTY)^2+ norm(beta*R)^2));

bk = 1;
bk_1 = 1; 

%% proximal gradient
while iter <= maxIter 
    W_s_k  = W_s + (bk_1 - 1)/bk * (W_s - W_s_1);
    grad = XTX*W_s_k*YTY - XTY*YTY +  alpha*(W_s_k*YTY - XTY) + beta*W_s_k*R;
    Gw_s_k = W_s_k - 1/Lip * grad;
    bk_1   = bk;
    bk     = (1 + sqrt(4*bk^2 + 1))/2;
    W_s_1  = W_s;
    W_s    = softthres(Gw_s_k,gamma/Lip);
    XWYT = X*W_s*Y';
    YWT = Y*W_s';
    predictionLoss = trace((XWYT - YYT)'*(XWYT - YYT))+alpha*trace((X-YWT)'*(X-YWT));
    correlation     = trace(R*W_s'*W_s);
    sparsity    = sum(sum(W_s~=0));
    totalloss = predictionLoss + beta*correlation + gamma*sparsity;
    
    if abs(oldloss - totalloss) <= miniLossMargin 
        break;
    elseif totalloss <=0 
        break;
    else      
        oldloss = totalloss;
    end
    obj_loss(iter) = oldloss;
    iter=iter+1;
end
model_DMSW = W_s;

end

%% soft thresholding operator 
function W = softthres(W_t,lambda) 
W = max(W_t-lambda,0) - max(-W_t-lambda,0);
end
